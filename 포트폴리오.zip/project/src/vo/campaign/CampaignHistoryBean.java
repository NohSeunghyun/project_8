package vo.campaign;

import java.sql.Date;

public class CampaignHistoryBean {
	private String campaign_supprot_campaign_name;
	private String campaign_supprot_group_name;
	private Date campaign_supprot_date;
	
	public String getCampaign_supprot_campaign_name() {
		return campaign_supprot_campaign_name;
	}
	public void setCampaign_supprot_campaign_name(String campaign_supprot_campaign_name) {
		this.campaign_supprot_campaign_name = campaign_supprot_campaign_name;
	}
	public String getCampaign_supprot_group_name() {
		return campaign_supprot_group_name;
	}
	public void setCampaign_supprot_group_name(String campaign_supprot_group_name) {
		this.campaign_supprot_group_name = campaign_supprot_group_name;
	}
	public Date getCampaign_supprot_date() {
		return campaign_supprot_date;
	}
	public void setCampaign_supprot_date(Date campaign_supprot_date) {
		this.campaign_supprot_date = campaign_supprot_date;
	}
}