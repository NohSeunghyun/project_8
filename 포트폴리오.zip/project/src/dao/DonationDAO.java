package dao;

import static db.JdbcUtil.close;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import vo.donation.DonationBankBean;
import vo.donation.DonationBean;
import vo.donation.DonationCardBean;

public class DonationDAO {
	Connection con = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	String sql = "";
	
	private static DonationDAO donationDAO;
	
	public static DonationDAO getInstance() {
		if (donationDAO == null) {
			donationDAO = new DonationDAO();
		}
		return donationDAO;
	}
	
	public void setConnection(Connection con) {
		this.con = con;
	}

	//일반회원 카드 기부 처리
	public int donationCardNormalMember(DonationBean donationInfo) {
		int donationCount = 0;
		try {
			sql = "insert into normalMember_donation_tbl(donation_member_id, donation_money, donation_date, donation_campaign_no, donation_type, pay_type, pay_status) values (?, ?, now(), ?, ?, ?, 'Y')";
			pstmt = con.prepareStatement(sql);
			
			pstmt.setString(1, donationInfo.getDonation_member_id());
			pstmt.setString(2, donationInfo.getDonation_money());
			pstmt.setInt(3, donationInfo.getDonation_campaign_no());
			pstmt.setString(4, donationInfo.getDonation_type());
			pstmt.setString(5, donationInfo.getPay_type());
			
			donationCount = pstmt.executeUpdate();
		} catch (Exception e) {
			System.out.println("donationCardNormalMember 에러 : " + e);
		} finally {
			close(pstmt);
		}
		return donationCount;
	}

	//기업/단체회원 카드 기부 처리
	public int donationCardComgrpMember(DonationBean donationInfo) {
		int donationCount = 0;
		try {
			sql = "insert into comgrpMember_donation_tbl(donation_member_id, donation_money, donation_date, donation_campaign_no, donation_type, pay_type, pay_status) values (?, ?, now(), ?, ?, ?, 'Y')";
			pstmt = con.prepareStatement(sql);
			
			pstmt.setString(1, donationInfo.getDonation_member_id());
			pstmt.setString(2, donationInfo.getDonation_money());
			pstmt.setInt(3, donationInfo.getDonation_campaign_no());
			pstmt.setString(4, donationInfo.getDonation_type());
			pstmt.setString(5, donationInfo.getPay_type());
			
			donationCount = pstmt.executeUpdate();
		} catch (Exception e) {
			System.out.println("donationCardComgrpMember 에러 : " + e);
		} finally {
			close(pstmt);
		}
		return donationCount;
	}

	//일반회원 계좌 기부 처리
	public int donationBankNormalMember(DonationBean donationInfo) {
		int donationCount = 0;
		try {
			sql = "insert into normalMember_donation_tbl(donation_member_id, donation_money, donation_date, donation_campaign_no, donation_type, pay_type, pay_status) values (?, ?, now(), ?, ?, ?, 'N')";
			pstmt = con.prepareStatement(sql);
			
			pstmt.setString(1, donationInfo.getDonation_member_id());
			pstmt.setString(2, donationInfo.getDonation_money());
			pstmt.setInt(3, donationInfo.getDonation_campaign_no());
			pstmt.setString(4, donationInfo.getDonation_type());
			pstmt.setString(5, donationInfo.getPay_type());
			
			donationCount = pstmt.executeUpdate();
		} catch (Exception e) {
			System.out.println("donationBankNormalMember 에러 : " + e);
		} finally {
			close(pstmt);
		}
		return donationCount;
	}

	//기업/단체회원 계좌 기부 처리
	public int donationBankComgrpMember(DonationBean donationInfo) {
		int donationCount = 0;
		try {
			sql = "insert into comgrpMember_donation_tbl(donation_member_id, donation_money, donation_date, donation_campaign_no, donation_type, pay_type, pay_status) values (?, ?, now(), ?, ?, ?, 'N')";
			pstmt = con.prepareStatement(sql);
			
			pstmt.setString(1, donationInfo.getDonation_member_id());
			pstmt.setString(2, donationInfo.getDonation_money());
			pstmt.setInt(3, donationInfo.getDonation_campaign_no());
			pstmt.setString(4, donationInfo.getDonation_type());
			pstmt.setString(5, donationInfo.getPay_type());
			
			donationCount = pstmt.executeUpdate();
		} catch (Exception e) {
			System.out.println("donationBankComgrpMember 에러 : " + e);
		} finally {
			close(pstmt);
		}
		return donationCount;
	}
	
	//일반회원 기부번호 가져오기
	public int getNormalMemberDonationNo() {
		int donation_no = 0;
		try {
			sql = "select max(donation_no) as donation_no from normalMember_donation_tbl";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				donation_no = rs.getInt("donation_no");
			}
		} catch (Exception e) {
			System.out.println("getNormalMemberDonationNo 에러 : " + e);
		} finally {
			close(rs);
			close(pstmt);
		}
		return donation_no;
	}
	
	//기업/단체회원 기부번호 가져오기
	public int getComgrpMemberDonationNo() {
		int donation_no = 0;
		try {
			sql = "select max(donation_no) as donation_no from comgrpMember_donation_tbl";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				donation_no = rs.getInt("donation_no");
			}
		} catch (Exception e) {
			System.out.println("getComgrpMemberDonationNo 에러 : " + e);
		} finally {
			close(rs);
			close(pstmt);
		}
		return donation_no;
	}

	//일반회원 카드 일시결제 정보 Insert
	public int donationNormalMemberTemporaryCardInfoInsert(DonationCardBean cardInfo) {
		int cardInfoInsertCount = 0;
		try {
			sql = "insert into normalMember_donation_cardInfo_tbl values (?, ?, ?, 'N')";
			pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1, cardInfo.getDonation_no());
			pstmt.setString(2, cardInfo.getCard_category());
			pstmt.setString(3, cardInfo.getCard_proprietor());
			
			cardInfoInsertCount = pstmt.executeUpdate();
		} catch (Exception e) {
			System.out.println("donationNormalMemberTemporaryCardInfoInsert 에러 : " + e);
		} finally {
			close(pstmt);
		}
		return cardInfoInsertCount;
	}

	//일반회원 카드 정기결제 정보 Insert
	public int donationNormalMemberRegularlyCardInfoInsert(DonationCardBean cardInfo) {
		int cardInfoInsertCount = 0;
		try {
			sql = "insert into normalMember_donation_cardInfo_tbl values (?, ?, ?, ?)";
			pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1, cardInfo.getDonation_no());
			pstmt.setString(2, cardInfo.getCard_category());
			pstmt.setString(3, cardInfo.getCard_proprietor());
			pstmt.setString(4, cardInfo.getPay_date());
			
			cardInfoInsertCount = pstmt.executeUpdate();
		} catch (Exception e) {
			System.out.println("donationNormalMemberRegularlyCardInfoInsert 에러 : " + e);
		} finally {
			close(pstmt);
		}
		return cardInfoInsertCount;
	}

	//기업/단체회원 카드 일시결제 정보 Insert
	public int donationComgrpMemberTemporaryCardInfoInsert(DonationCardBean cardInfo) {
		int cardInfoInsertCount = 0;
		try {
			sql = "insert into comgrpMember_donation_cardInfo_tbl values (?, ?, ?, 'N')";
			pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1, cardInfo.getDonation_no());
			pstmt.setString(2, cardInfo.getCard_category());
			pstmt.setString(3, cardInfo.getCard_proprietor());
			
			cardInfoInsertCount = pstmt.executeUpdate();
		} catch (Exception e) {
			System.out.println("donationComgrpMemberTemporaryCardInfoInsert 에러 : " + e);
		} finally {
			close(pstmt);
		}
		return cardInfoInsertCount;
	}

	//기업/단체회원 카드 정기결제 정보 Insert
	public int donationComgrpMemberRegularlyCardInfoInsert(DonationCardBean cardInfo) {
		int cardInfoInsertCount = 0;
		try {
			sql = "insert into comgrpMember_donation_cardInfo_tbl values (?, ?, ?, ?)";
			pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1, cardInfo.getDonation_no());
			pstmt.setString(2, cardInfo.getCard_category());
			pstmt.setString(3, cardInfo.getCard_proprietor());
			pstmt.setString(4, cardInfo.getPay_date());
			
			cardInfoInsertCount = pstmt.executeUpdate();
		} catch (Exception e) {
			System.out.println("donationComgrpMemberRegularlyCardInfoInsert 에러 : " + e);
		} finally {
			close(pstmt);
		}
		return cardInfoInsertCount;
	}

	//일반회원 계좌 일시결제 정보 Insert
	public int donationNormalMemberTemporaryBankInfoInsert(DonationBankBean bankInfo) {
		int bankInfoInsertCount = 0;
		try {
			sql = "insert into normalMember_donation_bankInfo_tbl values (?, ?, ?, ?, 'N')";
			pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1, bankInfo.getDonation_no());
			pstmt.setString(2, bankInfo.getBank_category());
			pstmt.setString(3, bankInfo.getBank_proprietor());
			pstmt.setString(4, bankInfo.getBank_name());
			
			bankInfoInsertCount = pstmt.executeUpdate();
		} catch (Exception e) {
			System.out.println("donationNormalMemberTemporaryBankInfoInsert 에러 : " + e);
		} finally {
			close(pstmt);
		}
		return bankInfoInsertCount;
	}

	//일반회원 계좌 정기결제 정보 Insert
	public int donationNormalMemberRegularlyBankInfoInsert(DonationBankBean bankInfo) {
		int bankInfoInsertCount = 0;
		try {
			sql = "insert into normalMember_donation_bankInfo_tbl values (?, ?, ?, ?, ?)";
			pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1, bankInfo.getDonation_no());
			pstmt.setString(2, bankInfo.getBank_category());
			pstmt.setString(3, bankInfo.getBank_proprietor());
			pstmt.setString(4, bankInfo.getBank_name());
			pstmt.setString(5, bankInfo.getPay_date());
			
			bankInfoInsertCount = pstmt.executeUpdate();
		} catch (Exception e) {
			System.out.println("donationNormalMemberRegularlyBankInfoInsert 에러 : " + e);
		} finally {
			close(pstmt);
		}
		return bankInfoInsertCount;
	}

	//기업/단체회원 계좌 일시결제 정보 Insert
	public int donationComgrpMemberTemporaryBankInfoInsert(DonationBankBean bankInfo) {
		int bankInfoInsertCount = 0;
		try {
			sql = "insert into comgrpMember_donation_bankInfo_tbl values (?, ?, ?, ?, 'N')";
			pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1, bankInfo.getDonation_no());
			pstmt.setString(2, bankInfo.getBank_category());
			pstmt.setString(3, bankInfo.getBank_proprietor());
			pstmt.setString(4, bankInfo.getBank_name());
			
			bankInfoInsertCount = pstmt.executeUpdate();
		} catch (Exception e) {
			System.out.println("donationComgrpMemberTemporaryBankInfoInsert 에러 : " + e);
		} finally {
			close(pstmt);
		}
		return bankInfoInsertCount;
	}

	//기업/단체회원 계좌 정기결제 정보 Insert
	public int donationComgrpMemberRegularlyBankInfoInsert(DonationBankBean bankInfo) {
		int bankInfoInsertCount = 0;
		try {
			sql = "insert into comgrpMember_donation_bankInfo_tbl values (?, ?, ?, ?, ?)";
			pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1, bankInfo.getDonation_no());
			pstmt.setString(2, bankInfo.getBank_category());
			pstmt.setString(3, bankInfo.getBank_proprietor());
			pstmt.setString(4, bankInfo.getBank_name());
			pstmt.setString(5, bankInfo.getPay_date());
			
			bankInfoInsertCount = pstmt.executeUpdate();
		} catch (Exception e) {
			System.out.println("donationComgrpMemberRegularlyBankInfoInsert 에러 : " + e);
		} finally {
			close(pstmt);
		}
		return bankInfoInsertCount;
	}
	
}
