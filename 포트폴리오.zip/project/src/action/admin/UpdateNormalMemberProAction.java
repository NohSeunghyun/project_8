package action.admin;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import action.Action;
import svc.login.UpdateMemberService;
import vo.ActionForward;
import vo.login.NormalMemberBean;

public class UpdateNormalMemberProAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward forward = null;
		
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		
		String birth = request.getParameter("member_birth1") + "-" + request.getParameter("member_birth2") + "-" + request.getParameter("member_birth3");
		
		NormalMemberBean normalMemberUpdate = new NormalMemberBean();
		
		normalMemberUpdate.setNormal_member_id(request.getParameter("member_id"));
		normalMemberUpdate.setNormal_member_name(request.getParameter("member_name"));
		normalMemberUpdate.setNormal_member_phone(request.getParameter("member_phone"));
		normalMemberUpdate.setNormal_member_birth(birth);
		normalMemberUpdate.setNormal_member_email(request.getParameter("member_email"));
		normalMemberUpdate.setNormal_member_gender(request.getParameter("member_gender"));
		
		UpdateMemberService updateMemberService = new UpdateMemberService();
		boolean isUpdateSuccess = updateMemberService.updateNormalMember(normalMemberUpdate);
		
		if (!isUpdateSuccess) {
			out.println("<script>");
			out.println("alert('회원수정에 실패하였습니다.');");
			out.println("window.opener='Self';");
			out.println("window.open('','_parent','');");
			out.println("window.close();");
			out.println("</script>");
		} else {
			forward = new ActionForward("admin_MemberUpdateSuccess.page", false);
		}
		return forward;
	}

}
