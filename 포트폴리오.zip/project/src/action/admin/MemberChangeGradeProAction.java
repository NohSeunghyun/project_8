package action.admin;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import action.Action;
import svc.admin.ChangeGradeService;
import svc.admin.ChangeInfoMemberChkService;
import vo.ActionForward;

public class MemberChangeGradeProAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward forward = null;
		
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		
		String id = request.getParameter("member_id");
		String Grade = request.getParameter("changeGrade");
		
		ChangeInfoMemberChkService changeInfoMemberChkService = new ChangeInfoMemberChkService();
		String category = changeInfoMemberChkService.isChangeInfoMemberCategory(id);
		
		if (category == "normal") {
			ChangeGradeService changeGradeService = new ChangeGradeService();
			boolean isNormalChangeGradeSuccess = changeGradeService.isNormalChangeGrade(id, Grade);
			
			if (!isNormalChangeGradeSuccess) {
				out.println("<script>");
				out.println("alert('회원등급 변경에 실패하였습니다.');");
				out.println("window.opener='Self';");
				out.println("window.open('','_parent','');");
				out.println("window.close();");
				out.println("</script>");
			} else {
				forward = new ActionForward("memberChangeGradeSuccess.page", false);
			}
		} else if (category == "comgrp") {
			ChangeGradeService changeGradeService = new ChangeGradeService();
			boolean isComgrpChangeGradeSuccess = changeGradeService.isComgrpChangeGrade(id, Grade);
			
			if (!isComgrpChangeGradeSuccess) {
				out.println("<script>");
				out.println("alert('회원등급 변경에 실패하였습니다.');");
				out.println("window.opener='Self';");
				out.println("window.open('','_parent','');");
				out.println("window.close();");
				out.println("</script>");
			} else {
				forward = new ActionForward("memberChangeGradeSuccess.page", false);
			}
		}
		return forward;
	}

}
