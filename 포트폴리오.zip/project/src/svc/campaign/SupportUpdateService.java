package svc.campaign;

import static db.JdbcUtil.*;

import java.sql.Connection;

import dao.CampaignDAO;

public class SupportUpdateService {

	public boolean supportUpdate(int group_no, String group_name, String group_intro) {
		boolean isSupportUpdateSuccess = false;
		Connection con = null;
		try {
			con = getConnection();
			CampaignDAO campaignDAO = CampaignDAO.getInstance();
			campaignDAO.setConnection(con);
			
			int updateCount = campaignDAO.supportUpdate(group_no, group_name, group_intro);
			
			if (updateCount > 0) {
				commit(con);
				isSupportUpdateSuccess = true;
			} else {
				rollback(con);
			}
		} catch (Exception e) {
			System.out.println("supportUpdateService 에러" + e);
		} finally {
			close(con);
		}
		return isSupportUpdateSuccess;
	}

}
