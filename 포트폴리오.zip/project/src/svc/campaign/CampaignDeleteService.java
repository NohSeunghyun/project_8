package svc.campaign;

import static db.JdbcUtil.*;

import java.sql.Connection;

import dao.CampaignDAO;

public class CampaignDeleteService {

	//캠페인 삭제 Service
	public boolean isCampaignDelete(int campaign_no) {
		boolean isCampaignDeleteSuccess = false;
		Connection con = null;
		try {
			con = getConnection();
			CampaignDAO campaignDAO = CampaignDAO.getInstance();
			campaignDAO.setConnection(con);
			
			int deleteCount = campaignDAO.campaignDelete(campaign_no);
			
			if (deleteCount > 0) {
				commit(con);
				isCampaignDeleteSuccess = true;
			} else {
				rollback(con);
			}
		} catch (Exception e) {
			System.out.println("isCampaignDeleteService 에러" + e);
		} finally {
			close(con);
		}
		return isCampaignDeleteSuccess;
	}

}
