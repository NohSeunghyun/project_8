package svc.campaign;

import static db.JdbcUtil.*;

import java.sql.Connection;

import dao.CampaignDAO;

public class GrantSendService {

	//지원금 전송 후 캠페인 잔액, 보낸 지원금 수정 Service
	public boolean grantSendCampaignInfoUpdate(int campaign_no, long amount) {
		boolean isCampaignInfoUpdateSuccess = false;
		Connection con = null;
		try {
			con = getConnection();
			CampaignDAO campaignDAO = CampaignDAO.getInstance();
			campaignDAO.setConnection(con);
			
			int updateCount = campaignDAO.grantSendCampaignInfoUpdate(campaign_no, amount);
			
			if (updateCount > 0) {
				commit(con);
				isCampaignInfoUpdateSuccess = true;
			} else {
				rollback(con);
			}
		} catch (Exception e) {
			System.out.println("grantSendCampaignInfoUpdateService 에러" + e);
		} finally {
			close(con);
		}
		return isCampaignInfoUpdateSuccess;
	}

	//지원금 전송 후 지원단체 지원금 수정 Service
	public boolean grantSendSupportGroupInfoUpdate(int group_no, long amount) {
		boolean isSupportGroupInfoUpdateSuccess = false;
		Connection con = null;
		try {
			con = getConnection();
			CampaignDAO campaignDAO = CampaignDAO.getInstance();
			campaignDAO.setConnection(con);
			
			int updateCount = campaignDAO.grantSendSupportGroupInfoUpdate(group_no, amount);
			
			if (updateCount > 0) {
				commit(con);
				isSupportGroupInfoUpdateSuccess = true;
			} else {
				rollback(con);
			}
		} catch (Exception e) {
			System.out.println("grantSendSupportGroupInfoUpdateService 에러" + e);
		} finally {
			close(con);
		}
		return isSupportGroupInfoUpdateSuccess;
	}

}
