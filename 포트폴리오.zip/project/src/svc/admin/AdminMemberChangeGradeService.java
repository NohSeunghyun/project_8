package svc.admin;

import static db.JdbcUtil.*;

import java.sql.Connection;

import dao.AdminDAO;

public class AdminMemberChangeGradeService {

	//관리자 등급 변경 Service
	public boolean isAdminMemberChangeGrade(String id, String changeGrade) {
		boolean isAdminMemberChangeGradeSuccess = false;
		int updateCount = 0;
		Connection con = null;
		try {
			con = getConnection();
			AdminDAO adminDAO = AdminDAO.getInstance();
			adminDAO.setConnection(con);
		
			updateCount = adminDAO.isAdminMemberChangeGrade(id, changeGrade);
			
			if (updateCount > 0) {
				commit(con);
				isAdminMemberChangeGradeSuccess = true;
			} else {
				rollback(con);
			}
		} catch (Exception e) {
			System.out.println("isAdminMemberChangeGradeService 에러" + e);
		} finally {
			close(con);
		}
		return isAdminMemberChangeGradeSuccess;
	}

}
