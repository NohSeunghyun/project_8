package svc.admin;

import static db.JdbcUtil.*;

import java.sql.Connection;

import dao.AdminDAO;
import vo.login.CompanyGroupMemberBean;
import vo.login.NormalMemberBean;

public class MemberInformationService {

	//관리자모드-일반회원 개인정보 조회 Service
	public NormalMemberBean adminNormalMemberInfo(String id) {
		NormalMemberBean normalInfo = null;
		Connection con = null;
		try {
			con = getConnection();
			AdminDAO adminDAO = AdminDAO.getInstance();
			adminDAO.setConnection(con);
			
			normalInfo = adminDAO.adminNormalMemberInfo(id);
		} catch (Exception e) {
			System.out.println("adminNormalMemberInfoService 에러" + e);
		} finally {
			close(con);
		}
		return normalInfo;
	}

	//관리자모드-기업/단체회원 개인정보 조회 Service
	public CompanyGroupMemberBean adminComgrpMemberInfo(String id) {
		CompanyGroupMemberBean comgrpInfo = null;
		Connection con = null;
		try {
			con = getConnection();
			AdminDAO adminDAO = AdminDAO.getInstance();
			adminDAO.setConnection(con);
			
			comgrpInfo = adminDAO.adminComgrpMemberInfo(id);
		} catch (Exception e) {
			System.out.println("adminComgrpMemberInfoService 에러" + e);
		} finally {
			close(con);
		}
		return comgrpInfo;
	}

}
