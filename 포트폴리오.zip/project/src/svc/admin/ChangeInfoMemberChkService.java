package svc.admin;

import static db.JdbcUtil.*;

import java.sql.Connection;

import dao.AdminDAO;

public class ChangeInfoMemberChkService {
	
	//관리자모드 회원정보 변경 전 회원구분 체크 Service
		public String isChangeInfoMemberCategory(String id) {
			String isMemberCategory = "";
			Connection con = null;
			try {
				con = getConnection();
				AdminDAO adminDAO = AdminDAO.getInstance();
				adminDAO.setConnection(con);
			
				isMemberCategory = adminDAO.isAdminMemberChangePwCategory(id);
			} catch (Exception e) {
				System.out.println("isChangeInfoMemberCategoryService 에러" + e);
			} finally {
				close(con);
			}
			return isMemberCategory;
		}

}
