package svc.admin;

import static db.JdbcUtil.*;

import java.sql.Connection;

import dao.AdminDAO;

public class AdminMemberChangePwService {

	//관리자 비밀번호 변경 Service
	public boolean isAdminMemberChangePw(String id, String changePw) {
		boolean isAdminMemberChangePwSuccess = false;
		int updateCount = 0;
		Connection con = null;
		try {
			con = getConnection();
			AdminDAO adminDAO = AdminDAO.getInstance();
			adminDAO.setConnection(con);
		
			updateCount = adminDAO.isAdminMemberChangePw(id, changePw);
			
			if (updateCount > 0) {
				commit(con);
				isAdminMemberChangePwSuccess = true;
			} else {
				rollback(con);
			}
		} catch (Exception e) {
			System.out.println("isAdminMemberChangePwService 에러" + e);
		} finally {
			close(con);
		}
		return isAdminMemberChangePwSuccess;
	}

}
