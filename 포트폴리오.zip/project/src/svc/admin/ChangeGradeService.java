package svc.admin;

import static db.JdbcUtil.*;

import java.sql.Connection;

import dao.AdminDAO;

public class ChangeGradeService {

	//일반회원 등급 수정 Service
	public boolean isNormalChangeGrade(String id, String grade) {
		boolean isNormalChangeGradeSuccess = false;
		int updateCount = 0;
		Connection con = null;
		try {
			con = getConnection();
			AdminDAO adminDAO = AdminDAO.getInstance();
			adminDAO.setConnection(con);
		
			updateCount = adminDAO.isNormalChangeGrade(id, grade);
			
			if (updateCount > 0) {
				commit(con);
				isNormalChangeGradeSuccess = true;
			} else {
				rollback(con);
			}
		} catch (Exception e) {
			System.out.println("isNormalChangeGradeService 에러" + e);
		} finally {
			close(con);
		}
		return isNormalChangeGradeSuccess;
	}

	//기업/단체회원 등급 수정 Service
	public boolean isComgrpChangeGrade(String id, String grade) {
		boolean isComgrpChangeGradeSuccess = false;
		int updateCount = 0;
		Connection con = null;
		try {
			con = getConnection();
			AdminDAO adminDAO = AdminDAO.getInstance();
			adminDAO.setConnection(con);
		
			updateCount = adminDAO.isComgrpChangeGrade(id, grade);
			
			if (updateCount > 0) {
				commit(con);
				isComgrpChangeGradeSuccess = true;
			} else {
				rollback(con);
			}
		} catch (Exception e) {
			System.out.println("isComgrpChangeGradeService 에러" + e);
		} finally {
			close(con);
		}
		return isComgrpChangeGradeSuccess;
	}

}
