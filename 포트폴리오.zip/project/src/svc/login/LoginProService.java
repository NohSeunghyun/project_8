package svc.login;

import static db.JdbcUtil.*;

import java.sql.Connection;

import dao.LoginDAO;

public class LoginProService {

	//로그인 아이디 확인 Service
	public String isIdChk(String id) {
		String isIdChk = "";
		Connection con = null;
		try {
			con = getConnection();
			LoginDAO loginDAO = LoginDAO.getInstance();
			loginDAO.setConnection(con);
	
			isIdChk = loginDAO.isIdChk(id);
		} catch (Exception e) {
			System.out.println("loginIdChkService 에러" + e);
		} finally {
			close(con);
		}
		return isIdChk;
	}

	//로그인 패스워드 확인 Service
	public String isPwChk(String id, String isIdChk, String pw) {
		String isPwChk = "";
		Connection con = null;
		try {
			con = getConnection();
			LoginDAO loginDAO = LoginDAO.getInstance();
			loginDAO.setConnection(con);
			
			isPwChk = loginDAO.isPwChk(id, isIdChk, pw);
		} catch (Exception e) {
			System.out.println("loginPwChkService 에러" + e);
		} finally {
			close(con);
		}
		return isPwChk;
	}

	//로그인 성공 후 세션에 담을 해당회원 이름 Service
	public String name(String id) {
		String name = "";
		Connection con = null;
		try {
			con = getConnection();
			LoginDAO loginDAO = LoginDAO.getInstance();
			loginDAO.setConnection(con);
			
			name = loginDAO.name(id);
		} catch (Exception e) {
			System.out.println("loginNameService 에러" + e);
		} finally {
			close(con);
		}
		return name;
		
	}
	
}
